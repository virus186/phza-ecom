<?php

return [
    'order_not_paid_yet' => 'The order is not paid yet!',
    'customer_wallet_not_enabled' => 'Customer wallet is not enabled!',
];
